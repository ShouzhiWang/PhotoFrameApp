//
//  ViewController.swift
//  PhotoFrame2
//
//  Created by 王首之 on 2021/9/2.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

